'use strict';

var require$$0 = require('fs-extra');
var require$$1 = require('upath');

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

var postinstall$1 = {};

var name = "@dimaslanjaka/eslint-base-config";
var version = "1.0.2";
var description = "Base ESLint configuration for JavaScript projects";
var main = "dist/eslint.config.cjs";
var module$1 = "dist/eslint.config.mjs";
var types = "dist/eslint.config.d.ts";
var bin = {
	"ebc-postinstall": "postinstall.cjs",
	"eslint-config-base": "postinstall.cjs",
	"init-ebc": "postinstall.cjs"
};
var files = [
	"./eslint.config.js",
	"./.prettierrc.json",
	"./dist",
	"./postinstall.cjs",
	"./.vscode/settings.json",
	"./oh-my-posh.config.*",
	"./scripts/*.ps1"
];
var exports$1 = {
	".": {
		"import": "./dist/eslint.config.mjs",
		require: "./dist/eslint.config.cjs",
		types: "./dist/eslint.config.d.ts"
	}
};
var keywords = [
];
var author = "Dimas Lanjaka";
var license = "ISC";
var type = "module";
var scripts = {
	build: "rollup -c rollup.config.js && npm run build-dts && copy .prettierrc.json ./dist/.prettierrc.json && node debug-tgz.mjs",
	"build-dts": "tsc -p tsconfig.dts.json && npx rimraf dist/src",
	pack: "node package.cjs",
	prepare: "husky",
	test: "node --experimental-vm-modules ./node_modules/jest/bin/jest.js --runInBand --detectOpenHandles --forceExit --bail=1",
	"test:coverage": "npm test -- --coverage",
	lint: "eslint \"src/**/*\" --fix",
	postinstall: "npx -y binary-collections@https://raw.githubusercontent.com/dimaslanjaka/bin/263fa06/releases/bin.tgz node-executor --exit-code=0 postinstall.cjs",
	postinstall2: "node postinstall.cjs",
	clean: "npx -y rimraf dist tmp"
};
var publishConfig = {
	access: "public"
};
var packageManager = "yarn@4.13.0";
var dependencies = {
	"@babel/core": "^7.29.0",
	"@babel/eslint-parser": "^7.28.6",
	"@babel/plugin-syntax-import-assertions": "^7.28.6",
	"@babel/preset-env": "^7.29.5",
	"@babel/preset-react": "^7.28.5",
	"@eslint/eslintrc": "3.3.5",
	"@eslint/js": "9",
	"@prettier/plugin-xml": "^3.4.2",
	"@typescript-eslint/eslint-plugin": "8.59.3",
	"@typescript-eslint/parser": "8.59.3",
	"cross-spawn": "^7.0.6",
	deepmerge: "^4.3.1",
	eslint: "9",
	"eslint-config-prettier": "10.1.8",
	"eslint-plugin-prettier": "5.5.5",
	"eslint-plugin-react": "^7.37.5",
	"eslint-plugin-react-hooks": "^7.1.1",
	"fs-extra": "^11.3.5",
	"jsonc-parser": "^3.3.1",
	prettier: "3.8.3",
	"prettier-plugin-embed": "^0.5.1",
	"prettier-plugin-sh": "^0.18.1",
	"prettier-plugin-sql": "^0.20.0",
	"prettier-plugin-twig": "^1.0.1",
	react: "^19.2.6",
	typescript: "^6.0.3",
	"typescript-eslint": "8.59.3",
	upath: "^3.0.7"
};
var devDependencies = {
	"@jest/environment": "^30.4.1",
	"@jest/expect": "^30.4.1",
	"@jest/globals": "^30.4.1",
	"@jest/test-sequencer": "^30.4.1",
	"@jest/types": "^30.4.1",
	"@rollup/plugin-commonjs": "^29.0.2",
	"@rollup/plugin-json": "^6.1.0",
	"@rollup/plugin-node-resolve": "^16.0.3",
	"@types/babel__core": "^7",
	"@types/babel__preset-env": "^7",
	"@types/fs-extra": "^11",
	"@types/react": "^19",
	"babel-jest": "^30.4.1",
	"binary-collections": "^2.0.11",
	husky: "^9.1.7",
	jest: "^30.4.2",
	"jest-config": "^30.4.2",
	"jest-mock": "^30.4.1",
	"lint-staged": "^17.0.5",
	rollup: "^4.60.4",
	"tar-stream": "^3.2.0",
	"ts-jest": "^29.4.11"
};
var resolutions = {
	"cross-spawn": "https://github.com/dimaslanjaka/node-cross-spawn/raw/78b09a1f799430fb251c1b438ec56ce7957674f4/release/cross-spawn.tgz",
	"binary-collections": "https://github.com/dimaslanjaka/bin/raw/9688287aecab1a125de2d63fdd30651017a9862e/releases/bin.tgz",
	"git-command-helper": "https://github.com/dimaslanjaka/git-command-helper/raw/dd8c8ef596083f367c592f97a2439f9fc8ab33b2/release/git-command-helper.tgz",
	"sbg-utility": "https://github.com/dimaslanjaka/static-blog-generator/raw/44e5c7b79b4e60f8c2d34857c27b8ce677d7493e/packages/sbg-utility/release/sbg-utility.tgz"
};
var require$$2 = {
	name: name,
	version: version,
	description: description,
	main: main,
	module: module$1,
	types: types,
	bin: bin,
	files: files,
	exports: exports$1,
	keywords: keywords,
	author: author,
	license: license,
	type: type,
	scripts: scripts,
	publishConfig: publishConfig,
	packageManager: packageManager,
	dependencies: dependencies,
	devDependencies: devDependencies,
	resolutions: resolutions
};

var checksum = {exports: {}};

var hasRequiredChecksum;

function requireChecksum () {
	if (hasRequiredChecksum) return checksum.exports;
	hasRequiredChecksum = 1;
	(function (module) {
		const hash = 'b54480d3a466e86738d56e6ed76aab35d13fd2bea5e614aec172a01c38f4fbe6';

		module.exports = hash;
		module.exports = { hash };
		module.exports.default = module.exports; 
	} (checksum));
	return checksum.exports;
}

var setupVSCodeConfiguration = {exports: {}};

var createDeduplicatingArrayMerger = {exports: {}};

var hasRequiredCreateDeduplicatingArrayMerger;

function requireCreateDeduplicatingArrayMerger () {
	if (hasRequiredCreateDeduplicatingArrayMerger) return createDeduplicatingArrayMerger.exports;
	hasRequiredCreateDeduplicatingArrayMerger = 1;
	function createDeduplicatingArrayMerger$1() {
	  return (existingItems, incomingItems) => {
	    const seenKeys = new Set();
	    const mergedItems = [];

	    for (const item of [...existingItems, ...incomingItems]) {
	      const uniqueKey = item && typeof item === 'object' ? JSON.stringify(item) : item;

	      if (!seenKeys.has(uniqueKey)) {
	        seenKeys.add(uniqueKey);
	        mergedItems.push(item);
	      }
	    }

	    return mergedItems;
	  };
	}

	createDeduplicatingArrayMerger.exports = createDeduplicatingArrayMerger$1;
	createDeduplicatingArrayMerger.exports.default = createDeduplicatingArrayMerger$1;
	return createDeduplicatingArrayMerger.exports;
}

var hasRequiredSetupVSCodeConfiguration;

function requireSetupVSCodeConfiguration () {
	if (hasRequiredSetupVSCodeConfiguration) return setupVSCodeConfiguration.exports;
	hasRequiredSetupVSCodeConfiguration = 1;
	const fs = require$$0;
	const path = require$$1;
	const createDeduplicatingArrayMerger = requireCreateDeduplicatingArrayMerger();

	async function importRuntimeDependencies() {
	  const deepmerge = (await import('deepmerge')).default;
	  const jsonc = (await import('jsonc-parser')).default;

	  return { deepmerge, jsonc };
	}

	async function setupVSCodeConfiguration$1(projectRoot = process.cwd()) {
	  const { deepmerge, jsonc } = await importRuntimeDependencies();

	  const projectSettingsPath = path.join(projectRoot, '.vscode', 'settings.json');
	  const packageSettingsPath = [
	    path.join(__dirname, '.vscode', 'settings.json'),
	    path.join(__dirname, '..', '.vscode', 'settings.json')
	  ].filter(fs.existsSync)[0];

	  if (!packageSettingsPath) {
	    console.warn('No .vscode/settings.json found in the package. Skipping VSCode configuration setup.');
	    return;
	  }

	  fs.ensureDirSync(path.dirname(projectSettingsPath));
	  fs.ensureDirSync(path.dirname(packageSettingsPath));

	  if (!fs.existsSync(projectSettingsPath)) {
	    fs.copyFileSync(packageSettingsPath, projectSettingsPath);

	    console.log(`Copied .vscode/settings.json to the ${projectRoot} project.`);

	    return;
	  }

	  const projectSettingsContent = fs.readFileSync(projectSettingsPath, 'utf-8');
	  const packageSettingsContent = fs.readFileSync(packageSettingsPath, 'utf-8');

	  const projectSettings = jsonc.parse(projectSettingsContent);
	  const packageSettings = jsonc.parse(packageSettingsContent);

	  const keysToMerge = [
	    'terminal.integrated.env.linux',
	    'terminal.integrated.env.windows',
	    'terminal.integrated.profiles.windows',
	    'eslint.probe',
	    'eslint.validate',
	    'eslint.useFlatConfig',
	    'editor.codeActionsOnSave'
	  ];

	  const mergedSettings = { ...projectSettings };

	  for (const key of keysToMerge) {
	    if (key in packageSettings) {
	      const existing = projectSettings[key];
	      const incoming = packageSettings[key];

	      if (existing == null || typeof existing !== 'object' || typeof incoming !== 'object') {
	        mergedSettings[key] = incoming;
	      } else {
	        mergedSettings[key] = deepmerge(existing, incoming, { arrayMerge: createDeduplicatingArrayMerger() });
	      }
	    }
	  }

	  fs.writeFileSync(projectSettingsPath, JSON.stringify(mergedSettings, null, 2));

	  console.log(`Merged .vscode/settings.json with selective deepmerge in the ${projectRoot} project.`);
	}

	setupVSCodeConfiguration.exports = setupVSCodeConfiguration$1;
	setupVSCodeConfiguration.exports.default = setupVSCodeConfiguration$1;
	return setupVSCodeConfiguration.exports;
}

var hasRequiredPostinstall;

function requirePostinstall () {
	if (hasRequiredPostinstall) return postinstall$1;
	hasRequiredPostinstall = 1;
	const fs = require$$0;
	const path = require$$1;
	const pkg = require$$2;
	const { hash } = requireChecksum();
	const setupVSCodeConfiguration = requireSetupVSCodeConfiguration();

	const isJest = process.env.JEST_WORKER_ID !== undefined;
	const cwd = process.env.INIT_CWD || process.cwd();

	// Derive the consumer project root from this script's own location.
	// When installed as a dependency, __dirname will be inside node_modules.
	// Walk up from node_modules to find the consumer's project root.
	const nmIndex = __dirname.replace(/\\/g, '/').lastIndexOf('/node_modules/');
	const consumerRoot = nmIndex !== -1 ? __dirname.slice(0, Math.max(0, nmIndex)) : cwd;

	const consumerPkgJsonPath = path.join(consumerRoot, 'package.json');

	try {
	  if (fs.existsSync(consumerPkgJsonPath)) {
	    const consumerPkg = fs.readJsonSync(consumerPkgJsonPath);

	    if (consumerPkg?.name && consumerPkg.name === pkg.name) {
	      console.warn(
	        `Warning: consumer package.json name (${pkg.name}) matches this package at ${consumerRoot}. ` +
	          `Skipping postinstall to avoid conflicts.`
	      );
	      process.exit(0);
	    }
	  }
	} catch (err) {
	  console.warn('Failed to validate consumer package.json:', err);
	}

	const basePath =
	  path.join(consumerRoot, 'tmp', '.postinstall-run')
	    ;

	const postinstallMarkerPath = path.join(basePath, `${hash}.txt`);

	function ensureDirSafe(dir) {
	  if (fs.existsSync(dir) && !fs.lstatSync(dir).isDirectory()) {
	    fs.removeSync(dir); // remove file blocking directory creation
	  }
	  fs.mkdirSync(dir, { recursive: true });
	}

	// skip if already done
	if (!isJest && fs.existsSync(postinstallMarkerPath)) {
	  console.log('Postinstall script has already been run. Skipping...');
	  process.exit(0);
	}

	async function run() {
	  try {
	    await setupVSCodeConfiguration(consumerRoot);

	    ensureDirSafe(basePath);

	    fs.writeFileSync(postinstallMarkerPath, `Postinstall script run on ${new Date().toISOString()}`);
	  } catch (err) {
	    console.error('Error during postinstall:', err);
	    process.exit(1);
	  }
	}

	run();
	return postinstall$1;
}

var postinstallExports = requirePostinstall();
var postinstall = /*@__PURE__*/getDefaultExportFromCjs(postinstallExports);

module.exports = postinstall;
